import random
from google.colab import files

# --- Настройки ---
DB_NAME_PLACEHOLDER = "hotels_db"
NUM_HOTELS = 5
NUM_ROOMS = 12
OUTPUT_SQL_FILENAME = "populate_hotels.sql"

# --- Данные для генерации ---
hotels_data = [
    ('Гранд Отель Европа', 'Санкт-Петербург', 5),
    ('Космос', 'Москва', 3),
    ('Амстердам', 'Москва', 4),
    ('Прибалтийская', 'Санкт-Петербург', 4),
    ('Волга', 'Ярославль', 3)
]

rooms_data = [
    (1, '101', 'Стандартный одноместный', 4500.00),
    (1, '102', 'Стандартный двухместный', 5200.00),
    (1, '201', 'Люкс', 8500.00),
    (2, '101', 'Эконом одноместный', 2500.00),
    (2, '102', 'Эконом двухместный', 2800.00),
    (2, '103', 'Стандартный', 3200.00),
    (3, '301', 'Бизнес-класс', 4200.00),
    (3, '302', 'Стандартный', 2900.00),
    (4, '501', 'С видом на море', 3800.00),
    (4, '502', 'Стандартный', 2700.00),
    (5, '201', 'Эконом', 2200.00),
    (5, '202', 'Комфорт', 2600.00)
]

# --- Функции для генерации SQL-запросов ---

def generate_hotels_insert_statements():
    """Генерирует INSERT запросы для таблицы Hotels."""
    inserts = []
    for hotel in hotels_data:
        name, city, stars = hotel
        inserts.append(
            f"INSERT INTO `Hotels` (`name`, `city`, `stars`) VALUES "
            f"('{name}', '{city}', {stars});"
        )
    return "\n".join(inserts)

def generate_rooms_insert_statements():
    """Генерирует INSERT запросы для таблицы Rooms."""
    inserts = []
    for room in rooms_data:
        hotel_id, room_number, room_type, price = room
        inserts.append(
            f"INSERT INTO `Rooms` (`hotel_id`, `room_number`, `type`, `price_per_night`) VALUES "
            f"({hotel_id}, '{room_number}', '{room_type}', {price:.2f});"
        )
    return "\n".join(inserts)

# --- Основная логика скрипта ---
sql_script_content = []
sql_script_content.append(f"-- SQL-скрипт для заполнения БД '{DB_NAME_PLACEHOLDER}'\n")
sql_script_content.append(f"USE `{DB_NAME_PLACEHOLDER}`;\n")

sql_script_content.append("-- Очистка таблиц перед вставкой новых данных\n")
sql_script_content.append("SET FOREIGN_KEY_CHECKS = 0;")
sql_script_content.append("TRUNCATE TABLE `Hotels`;")
sql_script_content.append("TRUNCATE TABLE `Rooms`;")
sql_script_content.append("SET FOREIGN_KEY_CHECKS = 1;\n")

sql_script_content.append("-- Заполнение таблицы 'Hotels'\n")
sql_script_content.append(generate_hotels_insert_statements())
sql_script_content.append("\n\n-- Добавление записей в таблицу rooms\n")
sql_script_content.append("-- Заполнение таблицы 'Rooms'\n")
sql_script_content.append(generate_rooms_insert_statements())

final_sql_string = "\n".join(sql_script_content)

# Создание и скачивание файла
with open(OUTPUT_SQL_FILENAME, "w", encoding="utf-8") as f:
    f.write(final_sql_string)

print(f"SQL-скрипт '{OUTPUT_SQL_FILENAME}' успешно сгенерирован.")
print("Сейчас начнется скачивание файла...")

files.download(OUTPUT_SQL_FILENAME)